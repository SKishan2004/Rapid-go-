import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CouponController extends GetxController {
  Rx<TextEditingController> couponController = TextEditingController().obs;
}
